# 🎮 Robux Gratis — Deploy ke Netlify

## 📁 Struktur File
```
robux-site/
├── netlify.toml                        ← konfigurasi Netlify
├── public/
│   └── index.html                      ← website utama
└── netlify/
    └── functions/
        └── verify-gamepass.js          ← serverless function (cek Roblox API)
```

---

## 🚀 Cara Deploy ke Netlify (GRATIS)

### Metode 1: Drag & Drop (Paling Mudah)
1. Pergi ke **netlify.com** → Login / Daftar gratis
2. Di dashboard, klik **"Add new site"** → **"Deploy manually"**
3. **Drag & drop folder `robux-site`** ke area upload
4. Tunggu 1-2 menit → Website langsung live! 🎉

### Metode 2: Via GitHub (Recommended untuk update)
1. Upload folder `robux-site` ke GitHub repo baru
2. Di Netlify → **"Add new site"** → **"Import from Git"**
3. Pilih repo GitHub kamu
4. Setting:
   - **Publish directory:** `public`
   - **Functions directory:** `netlify/functions`
5. Klik **Deploy** → Done!

---

## ✅ Cara Kerja Verifikasi

Ketika user memasukkan ID Gamepass:

```
Browser → Netlify Function → Roblox API → Hasil balik ke Browser
```

1. **Cek Username** → `users.roblox.com` (apakah username ada di Roblox)
2. **Cek Gamepass** → `economy.roblox.com/v1/game-passes/{id}/game-pass-product-info`
3. **Validasi Harga** → Harus tepat 72 Robux & sudah aktif dijual

### Contoh Response Berhasil:
- Gamepass ID valid ✅
- Harga tepat 72 Robux ✅  
- Status for sale = aktif ✅

### Contoh Response Gagal (Error Asli):
- `"Username tidak ditemukan di Roblox"` → username salah
- `"Gamepass ID 999 tidak ditemukan"` → ID salah
- `"Harga Gamepass adalah 50 Robux, bukan 72"` → harga salah
- `"Gamepass belum diaktifkan untuk dijual"` → belum di-enable

---

## 🔧 Test Lokal (Optional)
```bash
npm install -g netlify-cli
cd robux-site
netlify dev
```
Buka: http://localhost:8888

---

## ❓ FAQ

**Q: Apakah gratis?**
A: Ya! Netlify gratis untuk 125.000 function invocations/bulan.

**Q: Apakah verifikasi benar-benar ke Roblox?**
A: Ya! Fungsi `verify-gamepass.js` hit langsung ke API resmi Roblox.

**Q: Kenapa pakai Netlify Function, bukan langsung dari browser?**
A: Roblox API memblokir request langsung dari browser (CORS). Netlify Function jalan di server, jadi bisa akses Roblox API dengan normal.
