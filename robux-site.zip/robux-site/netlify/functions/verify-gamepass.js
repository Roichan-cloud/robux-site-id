// netlify/functions/verify-gamepass.js
// Serverless function - dipanggil dari browser, lalu dia yang hit Roblox API

exports.handler = async function (event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };

  // Handle preflight
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  const { gamepassId, username } = event.queryStringParameters || {};

  if (!gamepassId || !username) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, error: "Parameter tidak lengkap" }),
    };
  }

  // Validasi gamepassId harus angka
  if (!/^\d+$/.test(gamepassId)) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, error: "ID Gamepass harus berupa angka!" }),
    };
  }

  try {
    // === STEP 1: Cek username Roblox ===
    const userRes = await fetch(
      `https://users.roblox.com/v1/usernames/users`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
      }
    );
    const userData = await userRes.json();

    if (!userData.data || userData.data.length === 0) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: false,
          error: `Username "${username}" tidak ditemukan di Roblox!`,
        }),
      };
    }

    const robloxUser = userData.data[0];

    // === STEP 2: Cek info Gamepass ===
    const passRes = await fetch(
      `https://economy.roblox.com/v1/game-passes/${gamepassId}/game-pass-product-info`
    );

    if (passRes.status === 404) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: false,
          error: `Gamepass ID ${gamepassId} tidak ditemukan! Pastikan ID benar.`,
        }),
      };
    }

    const passData = await passRes.json();

    if (!passData || passData.errors) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: false,
          error: `Gamepass ID ${gamepassId} tidak valid atau tidak ditemukan.`,
        }),
      };
    }

    const gamepassName = passData.Name || "Unknown";
    const isForSale = passData.IsForSale;
    const price = passData.PriceInRobux;

    // === STEP 3: Validasi harga ===
    if (!isForSale) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: false,
          error: `Gamepass "${gamepassName}" belum diaktifkan untuk dijual! Aktifkan dulu di Roblox Creator Hub.`,
        }),
      };
    }

    if (price !== 72) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: false,
          error: `Harga Gamepass "${gamepassName}" adalah ${price} Robux, bukan 72 Robux! Ubah harganya menjadi tepat 72.`,
        }),
      };
    }

    // === SUCCESS ===
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        username: robloxUser.name,
        userId: robloxUser.id,
        gamepassName: gamepassName,
        gamepassId: gamepassId,
        price: price,
        message: `Verifikasi berhasil! Gamepass "${gamepassName}" milik ${robloxUser.name} seharga 72 Robux ditemukan.`,
      }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: "Gagal menghubungi server Roblox. Coba lagi beberapa saat.",
        detail: err.message,
      }),
    };
  }
};
